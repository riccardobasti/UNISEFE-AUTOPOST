<?php
/**
 * Plugin Name: UNISEFE Autopost
 * Description: Native WordPress campaign engine for scheduled AI-assisted publishing from prompts, sitemaps and feeds.
 * Version: 0.0.1
 * Author: Riccardo Bastillo
 * Requires at least: WordPress 6.0
 * Requires PHP: 8.0
 * Text Domain: unisefe-autopost
 * License: MIT
 */

if (!defined('ABSPATH')) {
    exit;
}

final class UNISEFE_Autopost {
    private const VERSION = '0.0.1';

    private const OPT_CAMPAIGNS = 'unisefe_autopost_campaigns';
    private const OPT_SETTINGS  = 'unisefe_autopost_settings';
    private const OPT_STATE     = 'unisefe_autopost_state';

    private const CRON_HOOK     = 'unisefe_autopost_campaign_run';

    private const PAGE_CAMPAIGNS = 'unisefe-autopost';
    private const PAGE_SETTINGS  = 'unisefe-autopost-settings';

    public function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'repair_campaign_schedules']);

        add_action('admin_post_unisefe_autopost_save_campaign', [$this, 'save_campaign']);
        add_action('admin_post_unisefe_autopost_delete_campaign', [$this, 'delete_campaign']);
        add_action('admin_post_unisefe_autopost_run_campaign', [$this, 'run_campaign_now']);
        add_action('admin_post_unisefe_autopost_toggle_campaign', [$this, 'toggle_campaign']);
        add_action('admin_post_unisefe_autopost_duplicate_campaign', [$this, 'duplicate_campaign']);
        add_action('admin_post_unisefe_autopost_save_settings', [$this, 'save_settings']);

        add_action(self::CRON_HOOK, [$this, 'cron_campaign_run'], 10, 1);
    }

    public static function activate(): void {
        $campaigns = get_option(self::OPT_CAMPAIGNS, []);
        if (!is_array($campaigns)) {
            return;
        }

        foreach ($campaigns as $id => $campaign) {
            if (!empty($campaign['active'])) {
                self::schedule_campaign($id, $campaign, false);
            }
        }
    }

    public static function deactivate(): void {
        $campaigns = get_option(self::OPT_CAMPAIGNS, []);
        if (!is_array($campaigns)) {
            return;
        }

        foreach (array_keys($campaigns) as $id) {
            self::clear_campaign_schedule((string) $id);
        }
    }

    public function admin_menu(): void {
        add_menu_page(
            __('UNISEFE Autopost', 'unisefe-autopost'),
            __('UNISEFE Autopost', 'unisefe-autopost'),
            'manage_options',
            self::PAGE_CAMPAIGNS,
            [$this, 'render_campaigns_page'],
            'dashicons-megaphone'
        );

        add_submenu_page(
            self::PAGE_CAMPAIGNS,
            __('Campaigns', 'unisefe-autopost'),
            __('Campaigns', 'unisefe-autopost'),
            'manage_options',
            self::PAGE_CAMPAIGNS,
            [$this, 'render_campaigns_page']
        );

        add_submenu_page(
            self::PAGE_CAMPAIGNS,
            __('AI Providers', 'unisefe-autopost'),
            __('AI Providers', 'unisefe-autopost'),
            'manage_options',
            self::PAGE_SETTINGS,
            [$this, 'render_settings_page']
        );
    }

    private function require_admin(string $action): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to perform this action.', 'unisefe-autopost'));
        }

        check_admin_referer($action);
    }

    private function campaigns_url(array $args = []): string {
        return add_query_arg($args, admin_url('admin.php?page=' . self::PAGE_CAMPAIGNS));
    }

    private function settings_url(array $args = []): string {
        return add_query_arg($args, admin_url('admin.php?page=' . self::PAGE_SETTINGS));
    }

    private static function interval_seconds(array $campaign): int {
        $interval = isset($campaign['interval']) ? (int) $campaign['interval'] : HOUR_IN_SECONDS;
        return max(MINUTE_IN_SECONDS, $interval);
    }

    private static function next_timestamp(array $campaign, ?int $from = null): int {
        $from = $from ?? time();
        return $from + self::interval_seconds($campaign);
    }

    private static function clear_campaign_schedule(string $id): void {
        $next = wp_next_scheduled(self::CRON_HOOK, [$id]);

        while ($next !== false) {
            wp_unschedule_event($next, self::CRON_HOOK, [$id]);
            $next = wp_next_scheduled(self::CRON_HOOK, [$id]);
        }
    }

    private static function schedule_campaign(string $id, array $campaign, bool $reset = true): void {
        if ($reset) {
            self::clear_campaign_schedule($id);
        }

        if (empty($campaign['active'])) {
            return;
        }

        if (wp_next_scheduled(self::CRON_HOOK, [$id])) {
            return;
        }

        $next = isset($campaign['next_run']) && (int) $campaign['next_run'] > time()
            ? (int) $campaign['next_run']
            : self::next_timestamp($campaign);

        wp_schedule_single_event($next, self::CRON_HOOK, [$id]);
    }

    public function repair_campaign_schedules(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $campaigns = get_option(self::OPT_CAMPAIGNS, []);
        if (!is_array($campaigns)) {
            return;
        }

        $changed = false;

        foreach ($campaigns as $id => &$campaign) {
            if (empty($campaign['active'])) {
                self::clear_campaign_schedule((string) $id);
                continue;
            }

            $next = wp_next_scheduled(self::CRON_HOOK, [(string) $id]);

            if ($next === false) {
                $campaign['next_run'] = self::next_timestamp($campaign);
                self::schedule_campaign((string) $id, $campaign, false);
                $changed = true;
            } elseif ((int) ($campaign['next_run'] ?? 0) !== (int) $next) {
                $campaign['next_run'] = (int) $next;
                $changed = true;
            }
        }
        unset($campaign);

        if ($changed) {
            update_option(self::OPT_CAMPAIGNS, $campaigns, false);
        }
    }

    private function get_campaigns(): array {
        $campaigns = get_option(self::OPT_CAMPAIGNS, []);
        return is_array($campaigns) ? $campaigns : [];
    }

    private function get_settings(): array {
        $settings = get_option(self::OPT_SETTINGS, []);
        return is_array($settings) ? $settings : [];
    }

    private function get_state(): array {
        $state = get_option(self::OPT_STATE, []);
        return is_array($state) ? $state : [];
    }

    private function save_state(array $state): void {
        update_option(self::OPT_STATE, $state, false);
    }

    public function save_campaign(): void {
        $this->require_admin('unisefe_autopost_save_campaign');

        $campaigns = $this->get_campaigns();

        $id = isset($_POST['campaign_id']) ? sanitize_key(wp_unslash($_POST['campaign_id'])) : '';
        if ($id === '') {
            $id = 'cmp_' . wp_generate_password(12, false, false);
        }

        $existing = $campaigns[$id] ?? [];

        $source_type = isset($_POST['source_type']) ? sanitize_key(wp_unslash($_POST['source_type'])) : 'prompt';
        if (!in_array($source_type, ['prompt', 'sitemap', 'feed'], true)) {
            $source_type = 'prompt';
        }

        $provider = isset($_POST['provider']) ? sanitize_key(wp_unslash($_POST['provider'])) : 'mock';
        if (!in_array($provider, ['mock', 'openrouter', 'openai', 'together'], true)) {
            $provider = 'mock';
        }

        $post_type = isset($_POST['post_type']) ? sanitize_key(wp_unslash($_POST['post_type'])) : 'post';
        if (!post_type_exists($post_type)) {
            $post_type = 'post';
        }

        $post_status = isset($_POST['post_status']) ? sanitize_key(wp_unslash($_POST['post_status'])) : 'draft';
        if (!in_array($post_status, ['draft', 'publish', 'pending', 'private'], true)) {
            $post_status = 'draft';
        }

        $interval = $this->parse_interval_from_request();

        $taxonomy = sanitize_key(wp_unslash($_POST['taxonomy'] ?? ''));
        $term = sanitize_title(wp_unslash($_POST['term'] ?? ''));
        $category = sanitize_text_field(wp_unslash($_POST['category'] ?? ''));

        if ($taxonomy !== '' && !taxonomy_exists($taxonomy)) {
            $taxonomy = '';
            $term = '';
        }

        if ($taxonomy !== '' && $term !== '') {
            $term_obj = get_term_by('slug', $term, $taxonomy);
            if (!$term_obj || is_wp_error($term_obj)) {
                $term = '';
            }
        }

        if ($category !== '') {
            $category_obj = get_term_by('name', $category, 'category');
            if (!$category_obj || is_wp_error($category_obj)) {
                $category = '';
            }
        }

        $campaign = [
            'name'          => sanitize_text_field(wp_unslash($_POST['name'] ?? __('Untitled campaign', 'unisefe-autopost'))),
            'active'        => !empty($_POST['active']),
            'source_type'   => $source_type,
            'prompt_items'  => sanitize_textarea_field(wp_unslash($_POST['prompt_items'] ?? '')),
            'source_url'    => esc_url_raw(trim(wp_unslash($_POST['source_url'] ?? ''))),
            'provider'      => $provider,
            'custom_prompt' => sanitize_textarea_field(wp_unslash($_POST['custom_prompt'] ?? '')),
            'rewrite_title' => !empty($_POST['rewrite_title']),
            'post_type'     => $post_type,
            'post_status'   => $post_status,
            'taxonomy'      => $taxonomy,
            'term'          => $term,
            'category'      => $category,
            'interval'      => $interval,
            'last_run'      => (int) ($existing['last_run'] ?? 0),
            'next_run'      => 0,
            'last_result'   => (string) ($existing['last_result'] ?? ''),
            'created_at'    => (int) ($existing['created_at'] ?? time()),
            'updated_at'    => time(),
        ];

        if ($campaign['active']) {
            $campaign['next_run'] = self::next_timestamp($campaign);
        }

        $campaigns[$id] = $campaign;
        update_option(self::OPT_CAMPAIGNS, $campaigns, false);

        self::clear_campaign_schedule($id);
        self::schedule_campaign($id, $campaign, false);

        wp_safe_redirect($this->campaigns_url(['saved' => '1']));
        exit;
    }

    private function parse_interval_from_request(): int {
        $preset = isset($_POST['interval_preset']) ? sanitize_key(wp_unslash($_POST['interval_preset'])) : '1h';

        $presets = [
            '5m'  => 5 * MINUTE_IN_SECONDS,
            '10m' => 10 * MINUTE_IN_SECONDS,
            '15m' => 15 * MINUTE_IN_SECONDS,
            '30m' => 30 * MINUTE_IN_SECONDS,
            '1h'  => HOUR_IN_SECONDS,
            '2h'  => 2 * HOUR_IN_SECONDS,
            '6h'  => 6 * HOUR_IN_SECONDS,
            '12h' => 12 * HOUR_IN_SECONDS,
            '1d'  => DAY_IN_SECONDS,
            '2d'  => 2 * DAY_IN_SECONDS,
            '7d'  => WEEK_IN_SECONDS,
        ];

        if ($preset !== 'custom') {
            return $presets[$preset] ?? HOUR_IN_SECONDS;
        }

        $value = isset($_POST['interval_value']) ? absint($_POST['interval_value']) : 1;
        $unit  = isset($_POST['interval_unit']) ? sanitize_key(wp_unslash($_POST['interval_unit'])) : 'hours';

        $multiplier = match ($unit) {
            'minutes' => MINUTE_IN_SECONDS,
            'days'    => DAY_IN_SECONDS,
            default   => HOUR_IN_SECONDS,
        };

        return max(MINUTE_IN_SECONDS, $value * $multiplier);
    }

    public function delete_campaign(): void {
        $this->require_admin('unisefe_autopost_delete_campaign');

        $id = sanitize_key(wp_unslash($_GET['campaign_id'] ?? ''));
        $campaigns = $this->get_campaigns();

        if ($id !== '' && isset($campaigns[$id])) {
            self::clear_campaign_schedule($id);
            unset($campaigns[$id]);
            update_option(self::OPT_CAMPAIGNS, $campaigns, false);

            $state = $this->get_state();
            unset($state[$id]);
            $this->save_state($state);
        }

        wp_safe_redirect($this->campaigns_url(['deleted' => '1']));
        exit;
    }

    public function toggle_campaign(): void {
        $this->require_admin('unisefe_autopost_toggle_campaign');

        $id = sanitize_key(wp_unslash($_GET['campaign_id'] ?? ''));
        $campaigns = $this->get_campaigns();

        if ($id !== '' && isset($campaigns[$id])) {
            $campaigns[$id]['active'] = empty($campaigns[$id]['active']);
            $campaigns[$id]['next_run'] = $campaigns[$id]['active']
                ? self::next_timestamp($campaigns[$id])
                : 0;

            update_option(self::OPT_CAMPAIGNS, $campaigns, false);

            self::clear_campaign_schedule($id);
            self::schedule_campaign($id, $campaigns[$id], false);
        }

        wp_safe_redirect($this->campaigns_url());
        exit;
    }

    public function duplicate_campaign(): void {
        $this->require_admin('unisefe_autopost_duplicate_campaign');

        $id = sanitize_key(wp_unslash($_GET['campaign_id'] ?? ''));
        $campaigns = $this->get_campaigns();

        if ($id !== '' && isset($campaigns[$id])) {
            $new_id = 'cmp_' . wp_generate_password(12, false, false);
            $copy = $campaigns[$id];
            $copy['name'] = sprintf(__('%s — Copy', 'unisefe-autopost'), $copy['name'] ?? __('Campaign', 'unisefe-autopost'));
            $copy['active'] = false;
            $copy['last_run'] = 0;
            $copy['next_run'] = 0;
            $copy['last_result'] = '';
            $copy['created_at'] = time();
            $copy['updated_at'] = time();

            $campaigns[$new_id] = $copy;
            update_option(self::OPT_CAMPAIGNS, $campaigns, false);
        }

        wp_safe_redirect($this->campaigns_url(['duplicated' => '1']));
        exit;
    }

    public function run_campaign_now(): void {
        $this->require_admin('unisefe_autopost_run_campaign');

        $id = sanitize_key(wp_unslash($_GET['campaign_id'] ?? ''));
        $result = $this->execute_campaign($id, true);

        wp_safe_redirect($this->campaigns_url(['ran' => $result ? '1' : '0']));
        exit;
    }

    public function cron_campaign_run(string $id): void {
        $this->execute_campaign($id, false);
    }

    private function execute_campaign(string $id, bool $manual): bool {
        $campaigns = $this->get_campaigns();

        if (!isset($campaigns[$id])) {
            return false;
        }

        $campaign = $campaigns[$id];

        if (!$manual && empty($campaign['active'])) {
            self::clear_campaign_schedule($id);
            return false;
        }

        $lock_key = 'unisefe_autopost_lock_' . md5($id);
        if (get_transient($lock_key)) {
            return false;
        }

        set_transient($lock_key, 1, 10 * MINUTE_IN_SECONDS);

        $ok = false;
        $message = '';

        try {
            $source = $this->next_source_item($id, $campaign);

            if (!$source) {
                $message = __('No new source item available.', 'unisefe-autopost');
            } else {
                $article = $this->build_article($campaign, $source);

                if (!$article) {
                    $message = __('AI generation failed.', 'unisefe-autopost');
                } else {
                    $post_id = $this->publish_article($campaign, $article, $source);

                    if ($post_id) {
                        $this->mark_source_processed($id, $campaign, $source);
                        $ok = true;
                        $message = sprintf(__('Created post #%d.', 'unisefe-autopost'), $post_id);
                    } else {
                        $message = __('WordPress could not create the post.', 'unisefe-autopost');
                    }
                }
            }
        } finally {
            delete_transient($lock_key);

            $campaigns = $this->get_campaigns();
            if (isset($campaigns[$id])) {
                $campaigns[$id]['last_run'] = time();
                $campaigns[$id]['last_result'] = $message;

                if (!empty($campaigns[$id]['active'])) {
                    $campaigns[$id]['next_run'] = self::next_timestamp($campaigns[$id]);
                } else {
                    $campaigns[$id]['next_run'] = 0;
                }

                update_option(self::OPT_CAMPAIGNS, $campaigns, false);

                self::clear_campaign_schedule($id);
                self::schedule_campaign($id, $campaigns[$id], false);
            }
        }

        return $ok;
    }

    private function next_source_item(string $id, array $campaign): ?array {
        return match ($campaign['source_type'] ?? 'prompt') {
            'sitemap' => $this->next_sitemap_item($id, $campaign),
            'feed'    => $this->next_feed_item($id, $campaign),
            default   => $this->next_prompt_item($id, $campaign),
        };
    }

    private function next_prompt_item(string $id, array $campaign): ?array {
        $lines = preg_split('/\R+/', (string) ($campaign['prompt_items'] ?? ''));
        $lines = array_values(array_filter(array_map('trim', is_array($lines) ? $lines : [])));

        if (!$lines) {
            return null;
        }

        $state = $this->get_state();
        $index = (int) ($state[$id]['prompt_index'] ?? 0);

        if ($index >= count($lines)) {
            return null;
        }

        return [
            'key'   => 'prompt:' . $index,
            'title' => $lines[$index],
            'text'  => $lines[$index],
            'url'   => '',
            'index' => $index,
        ];
    }

    private function next_sitemap_item(string $id, array $campaign): ?array {
        $url = trim((string) ($campaign['source_url'] ?? ''));
        if ($url === '') {
            return null;
        }

        $urls = $this->read_sitemap($url);
        if (!$urls) {
            return null;
        }

        $state = $this->get_state();
        $processed = $state[$id]['processed'] ?? [];
        if (!is_array($processed)) {
            $processed = [];
        }

        foreach ($urls as $page_url) {
            $key = sha1($page_url);
            if (isset($processed[$key])) {
                continue;
            }

            $response = wp_remote_get($page_url, [
                'timeout' => 25,
                'redirection' => 5,
                'user-agent' => 'UNISEFE-Autopost/' . self::VERSION . '; ' . home_url('/'),
            ]);

            if (is_wp_error($response)) {
                continue;
            }

            $html = wp_remote_retrieve_body($response);
            $text = $this->extract_text($html);

            if (mb_strlen($text) < 120) {
                continue;
            }

            return [
                'key'   => $key,
                'title' => wp_trim_words($text, 12, ''),
                'text'  => $text,
                'url'   => $page_url,
            ];
        }

        return null;
    }

    private function next_feed_item(string $id, array $campaign): ?array {
        $url = trim((string) ($campaign['source_url'] ?? ''));
        if ($url === '') {
            return null;
        }

        if (!function_exists('fetch_feed')) {
            require_once ABSPATH . WPINC . '/feed.php';
        }

        $feed = fetch_feed($url);
        if (is_wp_error($feed)) {
            return null;
        }

        $items = $feed->get_items(0, 20);
        if (!$items) {
            return null;
        }

        $state = $this->get_state();
        $processed = $state[$id]['processed'] ?? [];
        if (!is_array($processed)) {
            $processed = [];
        }

        foreach ($items as $item) {
            $permalink = (string) $item->get_permalink();
            $guid = (string) $item->get_id();
            $key = sha1($guid ?: $permalink ?: (string) $item->get_title());

            if (isset($processed[$key])) {
                continue;
            }

            $content = (string) ($item->get_content() ?: $item->get_description());
            $text = $this->extract_text($content);

            if (mb_strlen($text) < 60) {
                continue;
            }

            return [
                'key'   => $key,
                'title' => trim((string) $item->get_title()),
                'text'  => $text,
                'url'   => $permalink,
            ];
        }

        return null;
    }

    private function mark_source_processed(string $id, array $campaign, array $source): void {
        $state = $this->get_state();

        if (!isset($state[$id]) || !is_array($state[$id])) {
            $state[$id] = [];
        }

        if (($campaign['source_type'] ?? 'prompt') === 'prompt') {
            $state[$id]['prompt_index'] = ((int) ($source['index'] ?? 0)) + 1;
        } else {
            if (!isset($state[$id]['processed']) || !is_array($state[$id]['processed'])) {
                $state[$id]['processed'] = [];
            }

            $state[$id]['processed'][(string) $source['key']] = time();

            if (count($state[$id]['processed']) > 5000) {
                arsort($state[$id]['processed']);
                $state[$id]['processed'] = array_slice($state[$id]['processed'], 0, 5000, true);
            }
        }

        $this->save_state($state);
    }

    private function read_sitemap(string $url, int $depth = 0, array &$visited = []): array {
        if ($depth > 4 || isset($visited[$url])) {
            return [];
        }

        $visited[$url] = true;

        $response = wp_remote_get($url, [
            'timeout' => 25,
            'redirection' => 5,
            'user-agent' => 'UNISEFE-Autopost/' . self::VERSION . '; ' . home_url('/'),
        ]);

        if (is_wp_error($response)) {
            return [];
        }

        $body = wp_remote_retrieve_body($response);
        if ($body === '') {
            return [];
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($body);
        libxml_clear_errors();

        if (!$xml) {
            return [];
        }

        $urls = [];

        if ($xml->getName() === 'sitemapindex') {
            foreach ($xml->sitemap as $sitemap) {
                $child = esc_url_raw((string) $sitemap->loc);
                if ($child !== '') {
                    $urls = array_merge($urls, $this->read_sitemap($child, $depth + 1, $visited));
                }
            }
        } elseif ($xml->getName() === 'urlset') {
            foreach ($xml->url as $entry) {
                $page = esc_url_raw((string) $entry->loc);
                if ($page !== '') {
                    $urls[] = $page;
                }
            }
        }

        return array_values(array_unique($urls));
    }

    private function extract_text(string $html): string {
        if ($html === '') {
            return '';
        }

        $html = preg_replace('#<(script|style|noscript)[^>]*>.*?</\1>#is', ' ', $html);
        $html = preg_replace('#<!--.*?-->#s', ' ', $html);

        $text = wp_strip_all_tags((string) $html, true);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/[ \t]+/', ' ', $text);
        $text = preg_replace('/\R{3,}/', "\n\n", (string) $text);

        return trim((string) $text);
    }

    private function build_article(array $campaign, array $source): ?array {
        $provider = $campaign['provider'] ?? 'mock';

        if ($provider === 'mock') {
            return $this->mock_article($campaign, $source);
        }

        $system = "Scrivi un articolo originale in italiano basato esclusivamente sulle informazioni fornite.\n"
            . "Non inventare fatti, nomi, numeri o citazioni.\n"
            . "Restituisci solo JSON valido con due chiavi: title e content.\n"
            . "content deve contenere HTML WordPress semplice, preferibilmente paragrafi <p> e titoli <h2> quando utili.\n";

        if (!empty($campaign['custom_prompt'])) {
            $system .= "\nIstruzioni della campagna:\n" . trim((string) $campaign['custom_prompt']) . "\n";
        }

        $user = "Titolo/sorgente:\n" . (string) ($source['title'] ?? '') . "\n\n"
            . "Testo sorgente:\n" . (string) ($source['text'] ?? '');

        if (!empty($source['url'])) {
            $user .= "\n\nURL sorgente:\n" . (string) $source['url'];
        }

        $raw = $this->ai_call($provider, $system, $user);
        if ($raw === '') {
            return null;
        }

        $raw = trim($raw);
        $raw = preg_replace('/^```(?:json)?\s*/i', '', $raw);
        $raw = preg_replace('/\s*```$/', '', (string) $raw);

        $data = json_decode((string) $raw, true);
        if (!is_array($data)) {
            return null;
        }

        $title = sanitize_text_field((string) ($data['title'] ?? ''));
        $content = wp_kses_post((string) ($data['content'] ?? ''));

        if (empty($campaign['rewrite_title'])) {
            $title = sanitize_text_field((string) ($source['title'] ?? $title));
        }

        if ($title === '' || trim(wp_strip_all_tags($content)) === '') {
            return null;
        }

        return [
            'title' => $title,
            'content' => $content,
        ];
    }

    private function mock_article(array $campaign, array $source): array {
        $campaign_name = (string) ($campaign['name'] ?? 'UNISEFE Autopost');
        $source_title = (string) ($source['title'] ?? 'Test source');
        $source_url = (string) ($source['url'] ?? '');

        $title = '[TEST] ' . $source_title;

        $content = '<p><strong>UNISEFE Autopost — Mock/Test provider.</strong></p>';
        $content .= '<p>This post was generated without calling any paid AI API.</p>';
        $content .= '<p><strong>Campaign:</strong> ' . esc_html($campaign_name) . '</p>';
        $content .= '<p><strong>Source type:</strong> ' . esc_html((string) ($campaign['source_type'] ?? 'prompt')) . '</p>';

        if ($source_url !== '') {
            $content .= '<p><strong>Source URL:</strong> ' . esc_html($source_url) . '</p>';
        }

        if (!empty($campaign['custom_prompt'])) {
            $content .= '<p><strong>Campaign instructions:</strong> ' . esc_html((string) $campaign['custom_prompt']) . '</p>';
        }

        $preview = wp_trim_words((string) ($source['text'] ?? ''), 80, '…');
        if ($preview !== '') {
            $content .= '<h2>Source preview</h2><p>' . esc_html($preview) . '</p>';
        }

        return [
            'title' => $title,
            'content' => $content,
        ];
    }

    private function ai_call(string $provider, string $system, string $user): string {
        $settings = $this->get_settings();

        $config = match ($provider) {
            'openai' => [
                'key' => trim((string) ($settings['openai_key'] ?? '')),
                'model' => trim((string) ($settings['openai_model'] ?? 'gpt-5.6')),
                'endpoint' => 'https://api.openai.com/v1/responses',
            ],
            'together' => [
                'key' => trim((string) ($settings['together_key'] ?? '')),
                'model' => trim((string) ($settings['together_model'] ?? 'Qwen/Qwen2.5-7B-Instruct-Turbo')),
                'endpoint' => 'https://api.together.xyz/v1/chat/completions',
            ],
            default => [
                'key' => trim((string) ($settings['openrouter_key'] ?? '')),
                'model' => trim((string) ($settings['openrouter_model'] ?? 'openrouter/free')),
                'endpoint' => 'https://openrouter.ai/api/v1/chat/completions',
            ],
        };

        if ($config['key'] === '' || $config['model'] === '') {
            return '';
        }

        $headers = [
            'Authorization' => 'Bearer ' . $config['key'],
            'Content-Type' => 'application/json',
        ];

        if ($provider === 'openrouter') {
            $headers['HTTP-Referer'] = home_url('/');
            $headers['X-Title'] = get_bloginfo('name') ?: 'UNISEFE Autopost';
        }

        if ($provider === 'openai') {
            $body = [
                'model' => $config['model'],
                'input' => [
                    [
                        'role' => 'system',
                        'content' => [
                            ['type' => 'input_text', 'text' => $system],
                        ],
                    ],
                    [
                        'role' => 'user',
                        'content' => [
                            ['type' => 'input_text', 'text' => $user],
                        ],
                    ],
                ],
            ];
        } else {
            $body = [
                'model' => $config['model'],
                'messages' => [
                    ['role' => 'system', 'content' => $system],
                    ['role' => 'user', 'content' => $user],
                ],
                'temperature' => 0.4,
            ];
        }

        $response = wp_remote_post($config['endpoint'], [
            'headers' => $headers,
            'body' => wp_json_encode($body),
            'timeout' => 60,
        ]);

        if (is_wp_error($response)) {
            error_log('[UNISEFE Autopost] API request failed: ' . $response->get_error_message());
            return '';
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        if ($status < 200 || $status >= 300 || !is_array($data)) {
            return '';
        }

        if ($provider === 'openai') {
            $parts = [];

            foreach (($data['output'] ?? []) as $output) {
                if (($output['type'] ?? '') !== 'message') {
                    continue;
                }

                foreach (($output['content'] ?? []) as $content) {
                    if (($content['type'] ?? '') === 'output_text' && isset($content['text'])) {
                        $parts[] = (string) $content['text'];
                    }
                }
            }

            return trim(implode("\n", $parts));
        }

        return trim((string) ($data['choices'][0]['message']['content'] ?? ''));
    }

    private function publish_article(array $campaign, array $article, array $source): int {
        $post_id = wp_insert_post([
            'post_title' => sanitize_text_field((string) $article['title']),
            'post_content' => wp_kses_post((string) $article['content']),
            'post_type' => (string) ($campaign['post_type'] ?? 'post'),
            'post_status' => (string) ($campaign['post_status'] ?? 'draft'),
        ], true);

        if (is_wp_error($post_id) || !$post_id) {
            return 0;
        }

        if (!empty($source['url'])) {
            update_post_meta((int) $post_id, '_unisefe_autopost_source_url', esc_url_raw((string) $source['url']));
        }

        update_post_meta((int) $post_id, '_unisefe_autopost_campaign', sanitize_text_field((string) ($campaign['name'] ?? '')));

        $taxonomy = sanitize_key((string) ($campaign['taxonomy'] ?? ''));
        $term_slug = sanitize_title((string) ($campaign['term'] ?? ''));

        if ($taxonomy !== '' && $term_slug !== '' && taxonomy_exists($taxonomy)) {
            $term = get_term_by('slug', $term_slug, $taxonomy);
            if ($term && !is_wp_error($term)) {
                wp_set_post_terms((int) $post_id, [(int) $term->term_id], $taxonomy, false);
            }
        } elseif (!empty($campaign['category']) && taxonomy_exists('category')) {
            $category_name = sanitize_text_field((string) $campaign['category']);
            $exists = term_exists($category_name, 'category');

            if (!$exists) {
                $exists = wp_insert_term($category_name, 'category');
            }

            $term_id = 0;
            if (is_array($exists) && isset($exists['term_id'])) {
                $term_id = (int) $exists['term_id'];
            } elseif (is_int($exists)) {
                $term_id = $exists;
            }

            if ($term_id > 0) {
                wp_set_post_terms((int) $post_id, [$term_id], 'category', false);
            }
        }

        return (int) $post_id;
    }

    public function save_settings(): void {
        $this->require_admin('unisefe_autopost_save_settings');

        update_option(self::OPT_SETTINGS, [
            'openrouter_key' => sanitize_text_field(wp_unslash($_POST['openrouter_key'] ?? '')),
            'openrouter_model' => sanitize_text_field(wp_unslash($_POST['openrouter_model'] ?? 'openrouter/free')),
            'openai_key' => sanitize_text_field(wp_unslash($_POST['openai_key'] ?? '')),
            'openai_model' => sanitize_text_field(wp_unslash($_POST['openai_model'] ?? 'gpt-5.6')),
            'together_key' => sanitize_text_field(wp_unslash($_POST['together_key'] ?? '')),
            'together_model' => sanitize_text_field(wp_unslash($_POST['together_model'] ?? 'Qwen/Qwen2.5-7B-Instruct-Turbo')),
        ], false);

        wp_safe_redirect($this->settings_url(['saved' => '1']));
        exit;
    }

    public function render_campaigns_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_GET['new']) || isset($_GET['edit'])) {
            $id = isset($_GET['edit']) ? sanitize_key(wp_unslash($_GET['edit'])) : '';
            $campaigns = $this->get_campaigns();
            $campaign = ($id !== '' && isset($campaigns[$id])) ? $campaigns[$id] : [];
            $this->render_campaign_form($id, $campaign);
            return;
        }

        $campaigns = $this->get_campaigns();

        echo '<div class="wrap">';
        echo '<h1 class="wp-heading-inline">' . esc_html__('UNISEFE Autopost', 'unisefe-autopost') . '</h1> ';
        echo '<a class="page-title-action" href="' . esc_url($this->campaigns_url(['new' => '1'])) . '">' . esc_html__('New campaign', 'unisefe-autopost') . '</a>';
        echo '<hr class="wp-header-end">';

        foreach ([
            'saved' => __('Campaign saved.', 'unisefe-autopost'),
            'deleted' => __('Campaign deleted.', 'unisefe-autopost'),
            'duplicated' => __('Campaign duplicated in paused state.', 'unisefe-autopost'),
        ] as $key => $message) {
            if (isset($_GET[$key])) {
                echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
            }
        }

        if (isset($_GET['ran'])) {
            $ok = sanitize_key(wp_unslash($_GET['ran'])) === '1';
            echo '<div class="notice ' . ($ok ? 'notice-success' : 'notice-warning') . ' is-dismissible"><p>';
            echo esc_html($ok ? __('Campaign executed.', 'unisefe-autopost') : __('Campaign ran but no post was created.', 'unisefe-autopost'));
            echo '</p></div>';
        }

        if (!$campaigns) {
            echo '<p>' . esc_html__('No campaigns yet.', 'unisefe-autopost') . '</p>';
            echo '</div>';
            return;
        }

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__('Campaign', 'unisefe-autopost') . '</th>';
        echo '<th>' . esc_html__('Source', 'unisefe-autopost') . '</th>';
        echo '<th>' . esc_html__('Provider', 'unisefe-autopost') . '</th>';
        echo '<th>' . esc_html__('Frequency', 'unisefe-autopost') . '</th>';
        echo '<th>' . esc_html__('Last run', 'unisefe-autopost') . '</th>';
        echo '<th>' . esc_html__('Next run', 'unisefe-autopost') . '</th>';
        echo '<th>' . esc_html__('Status', 'unisefe-autopost') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($campaigns as $id => $campaign) {
            $edit_url = $this->campaigns_url(['edit' => $id]);
            $run_url = wp_nonce_url(
                admin_url('admin-post.php?action=unisefe_autopost_run_campaign&campaign_id=' . rawurlencode($id)),
                'unisefe_autopost_run_campaign'
            );
            $toggle_url = wp_nonce_url(
                admin_url('admin-post.php?action=unisefe_autopost_toggle_campaign&campaign_id=' . rawurlencode($id)),
                'unisefe_autopost_toggle_campaign'
            );
            $duplicate_url = wp_nonce_url(
                admin_url('admin-post.php?action=unisefe_autopost_duplicate_campaign&campaign_id=' . rawurlencode($id)),
                'unisefe_autopost_duplicate_campaign'
            );
            $delete_url = wp_nonce_url(
                admin_url('admin-post.php?action=unisefe_autopost_delete_campaign&campaign_id=' . rawurlencode($id)),
                'unisefe_autopost_delete_campaign'
            );

            $last_run = (int) ($campaign['last_run'] ?? 0);
            $next_run = (int) ($campaign['next_run'] ?? 0);
            $active = !empty($campaign['active']);

            echo '<tr>';
            echo '<td><strong><a href="' . esc_url($edit_url) . '">' . esc_html((string) ($campaign['name'] ?? '')) . '</a></strong>';
            echo '<div class="row-actions">';
            echo '<span><a href="' . esc_url($edit_url) . '">' . esc_html__('Edit', 'unisefe-autopost') . '</a> | </span>';
            echo '<span><a href="' . esc_url($run_url) . '">' . esc_html__('Run now', 'unisefe-autopost') . '</a> | </span>';
            echo '<span><a href="' . esc_url($toggle_url) . '">' . esc_html($active ? __('Pause', 'unisefe-autopost') : __('Resume', 'unisefe-autopost')) . '</a> | </span>';
            echo '<span><a href="' . esc_url($duplicate_url) . '">' . esc_html__('Duplicate', 'unisefe-autopost') . '</a> | </span>';
            echo '<span class="trash"><a href="' . esc_url($delete_url) . '">' . esc_html__('Delete', 'unisefe-autopost') . '</a></span>';
            echo '</div></td>';
            echo '<td>' . esc_html(ucfirst((string) ($campaign['source_type'] ?? 'prompt'))) . '</td>';
            echo '<td>' . esc_html(ucfirst((string) ($campaign['provider'] ?? 'mock'))) . '</td>';
            echo '<td>' . esc_html($this->format_interval((int) ($campaign['interval'] ?? HOUR_IN_SECONDS))) . '</td>';
            echo '<td>' . esc_html($last_run ? wp_date('Y-m-d H:i', $last_run) : __('Never', 'unisefe-autopost')) . '</td>';
            echo '<td>' . esc_html($active && $next_run ? wp_date('Y-m-d H:i', $next_run) : '—') . '</td>';
            echo '<td><strong>' . esc_html($active ? __('Active', 'unisefe-autopost') : __('Paused', 'unisefe-autopost')) . '</strong>';
            if (!empty($campaign['last_result'])) {
                echo '<br><small>' . esc_html((string) $campaign['last_result']) . '</small>';
            }
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }

    private function render_campaign_form(string $id, array $campaign): void {
        $defaults = [
            'name' => '',
            'active' => false,
            'source_type' => 'prompt',
            'prompt_items' => '',
            'source_url' => '',
            'provider' => 'mock',
            'custom_prompt' => '',
            'rewrite_title' => true,
            'post_type' => 'post',
            'post_status' => 'draft',
            'taxonomy' => '',
            'term' => '',
            'category' => '',
            'interval' => HOUR_IN_SECONDS,
        ];
        $campaign = array_merge($defaults, $campaign);

        $post_types = get_post_types(['public' => true], 'objects');
        $taxonomies = get_taxonomies(['public' => true], 'objects');

        $preset = $this->interval_preset((int) $campaign['interval']);

        echo '<div class="wrap">';
        echo '<h1>' . esc_html($id ? __('Edit campaign', 'unisefe-autopost') : __('New campaign', 'unisefe-autopost')) . '</h1>';
        echo '<p><a href="' . esc_url($this->campaigns_url()) . '">&larr; ' . esc_html__('Back to campaigns', 'unisefe-autopost') . '</a></p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="unisefe_autopost_save_campaign">';
        echo '<input type="hidden" name="campaign_id" value="' . esc_attr($id) . '">';
        wp_nonce_field('unisefe_autopost_save_campaign');

        echo '<table class="form-table" role="presentation">';

        echo '<tr><th scope="row"><label for="name">' . esc_html__('Campaign name', 'unisefe-autopost') . '</label></th><td>';
        echo '<input id="name" name="name" type="text" class="regular-text" required value="' . esc_attr((string) $campaign['name']) . '">';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__('Status', 'unisefe-autopost') . '</th><td>';
        echo '<label><input name="active" type="checkbox" value="1" ' . checked(!empty($campaign['active']), true, false) . '> ' . esc_html__('Active', 'unisefe-autopost') . '</label>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="source_type">' . esc_html__('Source type', 'unisefe-autopost') . '</label></th><td>';
        echo '<select id="source_type" name="source_type">';
        foreach ([
            'prompt' => __('Prompt / title list', 'unisefe-autopost'),
            'sitemap' => __('Sitemap', 'unisefe-autopost'),
            'feed' => __('RSS / Atom feed', 'unisefe-autopost'),
        ] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected((string) $campaign['source_type'], $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__('Unused source fields below are simply ignored. No JavaScript is required.', 'unisefe-autopost') . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="prompt_items">' . esc_html__('Prompt / title list', 'unisefe-autopost') . '</label></th><td>';
        echo '<textarea id="prompt_items" name="prompt_items" rows="8" class="large-text code">' . esc_textarea((string) $campaign['prompt_items']) . '</textarea>';
        echo '<p class="description">' . esc_html__('One title or prompt per line. Used by Prompt / title list campaigns.', 'unisefe-autopost') . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="source_url">' . esc_html__('Sitemap / feed URL', 'unisefe-autopost') . '</label></th><td>';
        echo '<input id="source_url" name="source_url" type="url" class="large-text code" value="' . esc_attr((string) $campaign['source_url']) . '">';
        echo '<p class="description">' . esc_html__('Used by Sitemap and RSS / Atom campaigns.', 'unisefe-autopost') . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="provider">' . esc_html__('AI provider', 'unisefe-autopost') . '</label></th><td>';
        echo '<select id="provider" name="provider">';
        foreach ([
            'mock' => __('Mock / Test — no API call', 'unisefe-autopost'),
            'openrouter' => 'OpenRouter',
            'openai' => 'OpenAI',
            'together' => 'Together AI',
        ] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected((string) $campaign['provider'], $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="custom_prompt">' . esc_html__('Campaign instructions', 'unisefe-autopost') . '</label></th><td>';
        echo '<textarea id="custom_prompt" name="custom_prompt" rows="6" class="large-text">' . esc_textarea((string) $campaign['custom_prompt']) . '</textarea>';
        echo '</td></tr>';

        echo '<tr><th scope="row">' . esc_html__('Title', 'unisefe-autopost') . '</th><td>';
        echo '<label><input name="rewrite_title" type="checkbox" value="1" ' . checked(!empty($campaign['rewrite_title']), true, false) . '> ' . esc_html__('Allow the AI provider to generate a new title', 'unisefe-autopost') . '</label>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="post_type">' . esc_html__('Post type', 'unisefe-autopost') . '</label></th><td>';
        echo '<select id="post_type" name="post_type">';
        foreach ($post_types as $post_type) {
            echo '<option value="' . esc_attr($post_type->name) . '" ' . selected((string) $campaign['post_type'], $post_type->name, false) . '>' . esc_html($post_type->labels->singular_name) . '</option>';
        }
        echo '</select>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="post_status">' . esc_html__('Post status', 'unisefe-autopost') . '</label></th><td>';
        echo '<select id="post_status" name="post_status">';
        foreach ([
            'draft' => __('Draft', 'unisefe-autopost'),
            'publish' => __('Publish', 'unisefe-autopost'),
            'pending' => __('Pending review', 'unisefe-autopost'),
            'private' => __('Private', 'unisefe-autopost'),
        ] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected((string) $campaign['post_status'], $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="taxonomy">' . esc_html__('Taxonomy', 'unisefe-autopost') . '</label></th><td>';
        echo '<select id="taxonomy" name="taxonomy"><option value="">' . esc_html__('None', 'unisefe-autopost') . '</option>';
        foreach ($taxonomies as $taxonomy) {
            echo '<option value="' . esc_attr($taxonomy->name) . '" ' . selected((string) $campaign['taxonomy'], $taxonomy->name, false) . '>' . esc_html($taxonomy->labels->singular_name) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__('Choose the taxonomy to use for this campaign.', 'unisefe-autopost') . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="term">' . esc_html__('Term', 'unisefe-autopost') . '</label></th><td>';
        echo '<select id="term" name="term">';
        echo '<option value="">' . esc_html__('None', 'unisefe-autopost') . '</option>';

        foreach ($taxonomies as $taxonomy) {
            $terms = get_terms([
                'taxonomy' => $taxonomy->name,
                'hide_empty' => false,
                'number' => 500,
            ]);

            if (is_wp_error($terms) || !$terms) {
                continue;
            }

            echo '<optgroup label="' . esc_attr($taxonomy->labels->singular_name) . '">';
            foreach ($terms as $term) {
                echo '<option value="' . esc_attr($term->slug) . '" ' . selected((string) $campaign['term'], $term->slug, false) . '>';
                echo esc_html($term->name . ' [' . $taxonomy->name . ']');
                echo '</option>';
            }
            echo '</optgroup>';
        }

        echo '</select>';
        echo '<p class="description">' . esc_html__('Terms are loaded server-side from WordPress. No AJAX is used.', 'unisefe-autopost') . '</p>';
        echo '</td></tr>';

        $categories = get_terms([
            'taxonomy' => 'category',
            'hide_empty' => false,
            'number' => 500,
        ]);

        echo '<tr><th scope="row"><label for="category">' . esc_html__('Category', 'unisefe-autopost') . '</label></th><td>';
        echo '<select id="category" name="category">';
        echo '<option value="">' . esc_html__('None', 'unisefe-autopost') . '</option>';

        if (!is_wp_error($categories)) {
            foreach ($categories as $category) {
                echo '<option value="' . esc_attr($category->name) . '" ' . selected((string) $campaign['category'], $category->name, false) . '>';
                echo esc_html($category->name);
                echo '</option>';
            }
        }

        echo '</select>';
        echo '<p class="description">' . esc_html__('Native WordPress categories. Used when no custom taxonomy/term is selected.', 'unisefe-autopost') . '</p>';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="interval_preset">' . esc_html__('Campaign frequency', 'unisefe-autopost') . '</label></th><td>';
        echo '<select id="interval_preset" name="interval_preset">';
        foreach ($this->interval_presets() as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected($preset, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '</td></tr>';

        $custom_minutes = max(1, (int) round(((int) $campaign['interval']) / 60));
        echo '<tr><th scope="row">' . esc_html__('Custom frequency', 'unisefe-autopost') . '</th><td>';
        echo '<input name="interval_value" type="number" min="1" step="1" class="small-text" value="' . esc_attr($custom_minutes) . '"> ';
        echo '<select name="interval_unit">';
        echo '<option value="minutes">' . esc_html__('Minutes', 'unisefe-autopost') . '</option>';
        echo '<option value="hours">' . esc_html__('Hours', 'unisefe-autopost') . '</option>';
        echo '<option value="days">' . esc_html__('Days', 'unisefe-autopost') . '</option>';
        echo '</select>';
        echo '<p class="description">' . esc_html__('Used only when Custom frequency is selected.', 'unisefe-autopost') . '</p>';
        echo '</td></tr>';

        echo '</table>';

        submit_button(__('Save campaign', 'unisefe-autopost'));
        echo '</form>';
        echo '</div>';
    }

    private function interval_presets(): array {
        return [
            '5m' => __('Every 5 minutes', 'unisefe-autopost'),
            '10m' => __('Every 10 minutes', 'unisefe-autopost'),
            '15m' => __('Every 15 minutes', 'unisefe-autopost'),
            '30m' => __('Every 30 minutes', 'unisefe-autopost'),
            '1h' => __('Every hour', 'unisefe-autopost'),
            '2h' => __('Every 2 hours', 'unisefe-autopost'),
            '6h' => __('Every 6 hours', 'unisefe-autopost'),
            '12h' => __('Every 12 hours', 'unisefe-autopost'),
            '1d' => __('Every day', 'unisefe-autopost'),
            '2d' => __('Every 2 days', 'unisefe-autopost'),
            '7d' => __('Every 7 days', 'unisefe-autopost'),
            'custom' => __('Custom', 'unisefe-autopost'),
        ];
    }

    private function interval_preset(int $seconds): string {
        $map = [
            5 * MINUTE_IN_SECONDS => '5m',
            10 * MINUTE_IN_SECONDS => '10m',
            15 * MINUTE_IN_SECONDS => '15m',
            30 * MINUTE_IN_SECONDS => '30m',
            HOUR_IN_SECONDS => '1h',
            2 * HOUR_IN_SECONDS => '2h',
            6 * HOUR_IN_SECONDS => '6h',
            12 * HOUR_IN_SECONDS => '12h',
            DAY_IN_SECONDS => '1d',
            2 * DAY_IN_SECONDS => '2d',
            WEEK_IN_SECONDS => '7d',
        ];

        return $map[$seconds] ?? 'custom';
    }

    private function format_interval(int $seconds): string {
        if ($seconds % WEEK_IN_SECONDS === 0) {
            return sprintf(_n('%d week', '%d weeks', $seconds / WEEK_IN_SECONDS, 'unisefe-autopost'), $seconds / WEEK_IN_SECONDS);
        }

        if ($seconds % DAY_IN_SECONDS === 0) {
            return sprintf(_n('%d day', '%d days', $seconds / DAY_IN_SECONDS, 'unisefe-autopost'), $seconds / DAY_IN_SECONDS);
        }

        if ($seconds % HOUR_IN_SECONDS === 0) {
            return sprintf(_n('%d hour', '%d hours', $seconds / HOUR_IN_SECONDS, 'unisefe-autopost'), $seconds / HOUR_IN_SECONDS);
        }

        return sprintf(_n('%d minute', '%d minutes', max(1, (int) round($seconds / 60)), 'unisefe-autopost'), max(1, (int) round($seconds / 60)));
    }

    public function render_settings_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = $this->get_settings();

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('UNISEFE Autopost — AI Providers', 'unisefe-autopost') . '</h1>';

        if (isset($_GET['saved'])) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Provider settings saved.', 'unisefe-autopost') . '</p></div>';
        }

        echo '<p>' . esc_html__('Mock/Test needs no key and never calls an external AI API.', 'unisefe-autopost') . '</p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="unisefe_autopost_save_settings">';
        wp_nonce_field('unisefe_autopost_save_settings');

        echo '<table class="form-table" role="presentation">';

        $this->provider_fields('OpenRouter', 'openrouter', $settings['openrouter_key'] ?? '', $settings['openrouter_model'] ?? 'openrouter/free');
        $this->provider_fields('OpenAI', 'openai', $settings['openai_key'] ?? '', $settings['openai_model'] ?? 'gpt-5.6');
        $this->provider_fields('Together AI', 'together', $settings['together_key'] ?? '', $settings['together_model'] ?? 'Qwen/Qwen2.5-7B-Instruct-Turbo');

        echo '</table>';
        submit_button(__('Save provider settings', 'unisefe-autopost'));
        echo '</form>';

        echo '<hr>';
        echo '<h2>' . esc_html__('Zero-cost testing', 'unisefe-autopost') . '</h2>';
        echo '<p>' . esc_html__('Create a campaign with provider “Mock / Test” and post status “Draft”. The full campaign, scheduling, source and publishing pipeline can then be tested without spending API credit.', 'unisefe-autopost') . '</p>';

        echo '</div>';
    }

    private function provider_fields(string $title, string $slug, string $key, string $model): void {
        echo '<tr><th scope="row" colspan="2"><h2>' . esc_html($title) . '</h2></th></tr>';

        echo '<tr><th scope="row"><label for="' . esc_attr($slug) . '_key">' . esc_html__('API key', 'unisefe-autopost') . '</label></th><td>';
        echo '<input id="' . esc_attr($slug) . '_key" name="' . esc_attr($slug) . '_key" type="password" autocomplete="off" class="regular-text code" value="' . esc_attr($key) . '">';
        echo '</td></tr>';

        echo '<tr><th scope="row"><label for="' . esc_attr($slug) . '_model">' . esc_html__('Model', 'unisefe-autopost') . '</label></th><td>';
        echo '<input id="' . esc_attr($slug) . '_model" name="' . esc_attr($slug) . '_model" type="text" class="regular-text code" value="' . esc_attr($model) . '">';
        echo '</td></tr>';
    }
}

$unisefe_autopost = new UNISEFE_Autopost();

register_activation_hook(__FILE__, ['UNISEFE_Autopost', 'activate']);
register_deactivation_hook(__FILE__, ['UNISEFE_Autopost', 'deactivate']);
